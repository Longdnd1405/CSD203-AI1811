class Bird:
    def __init__(self, xType, xRate, xWing):
        self.type = xType
        self.rate = xRate
        self.wing = xWing

class BSTree:
    def __init__(self):
        self.root = None

    def f0(self):
        return "Hexxxxxx"  # Fill in your own RollNumber

    def insert(self, xType, xRate, xWing):
        if xType[0] != 'B' and xRate <= 10:
            new_bird = Bird(xType, xRate, xWing)
            if self.root is None:
                self.root = new_bird
            else:
                self._insert_recursive(self.root, new_bird)

    def _insert_recursive(self, node, new_bird):
        if new_bird.rate < node.rate:
            if not hasattr(node, 'left'):
                node.left = new_bird
            else:
                self._insert_recursive(node.left, new_bird)
        elif new_bird.rate > node.rate:
            if not hasattr(node, 'right'):
                node.right = new_bird
            else:
                self._insert_recursive(node.right, new_bird)

    def f1(self):
        self._in_order_traversal(self.root)

    def _in_order_traversal(self, node):
        if node:
            self._in_order_traversal(node.left)
            print(f'({node.type},{node.rate},{node.wing})', end=' ')
            self._in_order_traversal(node.right)

    def f2(self):
        self._pre_order_filter(self.root)

    def _pre_order_filter(self, node):
        if node:
            if 4 <= node.wing <= 10:
                print(f'({node.type},{node.rate},{node.wing})', end=' ')
            self._pre_order_filter(node.left)
            self._pre_order_filter(node.right)

    def f3(self):
        queue = [self.root]
        odd = True
        while queue:
            n = len(queue)
            for i in range(n):
                node = queue.pop(0)
                if odd:
                    print(f'({node.type},{node.rate},{node.wing})', end=' ')
                if node.left:
                    queue.append(node.left)
                if node.right:
                    queue.append(node.right)
            odd = not odd

    def f4(self):
        self._post_order_filter(self.root)

    def _post_order_filter(self, node):
        if node:
            self._post_order_filter(node.left)
            self._post_order_filter(node.right)
            if node.wing <= 4 and node.rate > 6:
                print(f'({node.type},{node.rate},{node.wing})', end=' ')

    def f5(self):
        self._in_order_filter(self.root)

    def _in_order_filter(self, node):
        if node:
            self._in_order_filter(node.left)
            if node.type[0] == 'A' or node.type[0] == 'C':
                print(f'({node.type},{node.rate},{node.wing})', end=' ')
            self._in_order_filter(node.right)